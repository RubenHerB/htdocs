<?php if(\Session::get("success")): ?>
    <div class="alert alert-success text-center">
        <p><?php echo e(\Session::get("success")); ?></p>
    </div>
<?php elseif(\Session::get("deny")): ?>
<div class="alert alert-danger text-center">
        <p><?php echo e(\Session::get("deny")); ?></p>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\proyecto\CARRITO\carritoRubenHernando\resources\views/partials/msg.blade.php ENDPATH**/ ?>