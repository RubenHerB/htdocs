<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <!--<link href="/assets/css/estilos.css" rel="stylesheet">-->

    <style>
        @font-face {
    font-family: 'Montserrat';
    src: url('/css/monstserrat/Montserrat-VariableFont_wght.ttf') format('truetype');   
  }
  @font-face {
    font-family: 'Lato';
    src: url('/css/lato/Lato-Regular.ttf') format('truetype');   
  }
  @font-face{
    font-family: 'Playfare';
    src: url('/css/playfair/PlayfairDisplay-VariableFont_wght.ttf') format('truetype');
  }

  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    font-family: 'Montserrat', sans-serif;
}

html{background: url("<?php echo e(URL('/img/llagar.png')); ?>") no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;background-color: black;}

  .titulo {font-size: 35px;font-family: 'Playfare', sans-serif;color: #4b4b4b;vertical-align: middle;}
.titulo span{color: black;font-family: 'Playfare', sans-serif;}

nav{
    background-color: #13E674;
}
.imagenico{
    max-width: 60px;
    height: auto;
}
.nav-link{
  padding: 35.5px 50px;
        font-family: 'Lato', sans-serif;
}

.nav-link:hover{background-color: #13C774;
  -webkit-animation: color_change 0.5s;
  -moz-animation: color_change 0.5s;
  -ms-animation: color_change 0.5s;
  -o-animation: color_change 0.5s;
  animation: color_change 0.5s;}

  @-webkit-keyframes color_change {
    from { background-color: #13E674; }
    to { background-color: #13C774; }
}
@-moz-keyframes color_change {
    from { background-color: #13E674; }
    to { background-color: #13C774; }
}
@-ms-keyframes color_change {
    from { background-color: #13E674; }
    to { background-color: #13C774; }
}
@-o-keyframes color_change {
    from { background-color: #13E674; }
    to { background-color: #13C774; }
}
@keyframes color_change {
    from { background-color: #13E674; }
    to { background-color: #13C774; }
}
.redes a img{height: auto;width: 45px ;border-radius: 1%;padding: 3px;}

    </style>
    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>
<body class="bg-transparent">
    <div id="app" class="bg-transparent">
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="py-4 bg-transparent">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\proyecto\CARRITO\carritoRubenHernando\resources\views/layouts/app.blade.php ENDPATH**/ ?>