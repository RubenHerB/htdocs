<nav class="navbar navbar-expand-lg">
      <div class="container-fluid ">
        <a class="navbar-brand titulo icon-link" href="index.html">
          <div class="row justify-content-start align-items-center">
            <div class="col col-md-2"><img src="<?php echo e(URL('img/botella.png')); ?>" alt="Logo" class="img-fluid imagenico"> </div>
            <div class="col col-md-10 text-wrap text-md-nowrap titulo">Llagar <span>El Sidrero</span> 1952</div>
          </div>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
          <ul class="navbar-nav mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="<?php echo e(URL('/')); ?>">Inicio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(URL('/visitas')); ?>">Visitanos</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(URL('/productos')); ?>">Nuestros productos</a>
            </li>
            
            

                    <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('checkout')); ?>">Carrito <span class="badge bg-danger"><?php echo e(Cart::count()); ?></span></a>
                                </li>
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav><?php /**PATH C:\xampp\htdocs\proyecto\CARRITO\carritoRubenHernando\resources\views/partials/navbar.blade.php ENDPATH**/ ?>