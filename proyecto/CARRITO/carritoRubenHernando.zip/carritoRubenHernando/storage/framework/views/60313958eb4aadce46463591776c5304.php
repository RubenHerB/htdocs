

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-md-10 align-self-center">
            <div class="row justify-content-center">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-3 col-md-6 col-lg-5 col-sm-8 ">
                    <div class="card">
                        <img src="<?php echo e(URL('img/'.$item->imagen)); ?>" class="card-img-top" />
                        <div class="card-body">
                            <h2><?php echo e($item->name); ?></h2>
                            <p><?php echo e($item->precio); ?> €</p>
                        </div>
                        <div class="card-footer">
                            <form action="<?php echo e(route('add')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($item->id); ?>" />
                                <input type="submit" name="btn" value="Añadir al carrito" class="btn btn-success w-100" />
</form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\CARRITO\carritoRubenHernando\resources\views/portfolio/productos.blade.php ENDPATH**/ ?>