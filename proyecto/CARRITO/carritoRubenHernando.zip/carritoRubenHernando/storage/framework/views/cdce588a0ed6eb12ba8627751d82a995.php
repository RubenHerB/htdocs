<div class="row footer mt-5">
<footer id="footer" class="flex-shrink-0 py-4 bg-dark text-white-50">

    <div class="text-center row justify-content-around">
      <div class="col-auto">Contactanos:<br> 
        info@llagarelsidrero.com<br>
        +34 123 456 789
      </div>
      
      <div class="col-auto">
        Siguenos:
        <div class="redes">
        <a href="https://youtube.com"><img src="<?php echo e(URL('img/yt.png')); ?>" alt="Simbolo de x"></a>
        <a href="https://twitter.com"><img src="<?php echo e(URL('img/x.png')); ?>" alt="Simbolo de x"></a>
        <a href="https://facebook.com"><img src="<?php echo e(URL('img/fb.png')); ?>" alt="Simbolo de x"></a>
        <a href="https://instagram.com"><img src="<?php echo e(URL('img/insta.png')); ?>" alt="Simbolo de x"></a>
      </div>
      </div>
    </div>
  </footer>
</div><?php /**PATH C:\xampp\htdocs\proyecto\CARRITO\carritoRubenHernando\resources\views/partials/footer.blade.php ENDPATH**/ ?>