

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-md-10">
            <?php if(Cart::count()): ?>
            <div class="row justify-content-between text-center mb-3">
                <div class="col">
                <form method="get" action="<?php echo e(route('clear')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="submit" name="btn" value="Vaciar carrito" class="btn btn-danger w-20" />
                </form>
                </div>
                <div class="col">
                <form method="get" action="<?php echo e(route('comprar')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="submit" name="btn" value="Realizar compra" class="btn btn-primary w-20" />
                </form>
                </div>
            </div>
                <table class="table table-striped">
                    <thead>
                        <th></th>
                        <th>NOMBRE</th>
                        <th>CANTIDAD</th>
                        <th>PRECIO UNITARIO</th>
                        <th>IMPORTE</th>
                        <th></th>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="align-middle">
                                <td><img src="<?php echo e(URL('/img/'.$item->options->image)); ?>" style="width:50px"></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->qty); ?></td>
                                <td><?php echo e(number_format($item->price,2)); ?></td>
                                <td><?php echo e(number_format($item->price*$item->qty,2)); ?></td>
                                <td>
                                    <form method="post" action="<?php echo e(route('removeone')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($item->rowId); ?>" />
                                        <input type="submit" name="btn" value="Quitar uno" class="btn btn-danger w-100" />
                                    </form>
                                </td>
                                <td>
                                    <form method="post" action="<?php echo e(route('removeitem')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($item->rowId); ?>" />
                                        <input type="submit" name="btn" value="Quitar todos" class="btn btn-danger w-100" />
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr class="fw-bolder">
                            <td colspan="5"></td>
                            <td class="text-end">Total</td>
                            <td class="text-end"><?php echo e(Cart::subtotal()); ?></td>
                        </tr>
                    </tbody>
                </table>
            <?php else: ?>
                <a href="<?php echo e(URL('/productos')); ?>" class="text-center">Agregar productos</a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto\CARRITO\carritoRubenHernando\resources\views/portfolio/checkout.blade.php ENDPATH**/ ?>